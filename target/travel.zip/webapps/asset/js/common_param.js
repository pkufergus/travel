/**
 * 
 */
var common_path = "/v1/";